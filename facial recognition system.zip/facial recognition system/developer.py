from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector
import cv2   #open source computer vision libraray


mydb = mysql.connector.connect(host="localhost",user="root")



class developer:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("face recognition system")

        title=Label(self.root,text="DEVELOPER", font=("times new roman",35,"bold"), bg="white", fg="black")
        title.place(x=0,y=0,width=1300,height=50)

        #top image
        img_top= Image.open(r"images\64d6bd51ab17a00828b644bf_header.webp")
        img_top = img_top.resize((1530, 580), Image.LANCZOS)  
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimg_top)
        f_lbl.place(x=0, y=50, width=1530, height=580)

        main_frame=Frame(f_lbl,bd=2,bg="white")
        main_frame.place(x=850,y=25,width=400,height=530)

        img_top1= Image.open(r"images\64d6bd51ab17a00828b644bf_header.webp")
        img_top1 = img_top1.resize((180, 180), Image.LANCZOS)  
        self.photoimg_top1 = ImageTk.PhotoImage(img_top1)

        f_lbl = Label(main_frame, image=self.photoimg_top1)
        f_lbl.place(x=120, y=25, width=180, height=180)

        #developer info
        dev_label=Label(main_frame,text="Hello, my name is Dhun",font=("times new roman",20,"bold"),bg="white")
        dev_label.place(x=70,y=230)





if __name__ == "__main__":
    root = Tk()
    obj = developer(root)
    root.mainloop()
