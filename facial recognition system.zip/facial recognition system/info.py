from screeninfo import get_monitors

for monitor in get_monitors():
    print(f"Screen width: {monitor.width}")
    print(f"Screen height: {monitor.height}")
