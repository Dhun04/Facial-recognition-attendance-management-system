from tkinter import *
from tkinter import ttk
import tkinter
import os
from PIL import Image,ImageTk
from tkinter import messagebox
from main import face_recog
from time import strftime
from datetime import datetime
import mysql.connector



mydb = mysql.connector.connect(host="localhost",user="root")


def main():
    win = Tk()
    app=login_window(win)
    win.mainloop()

class login_window:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("face recognition system")

        #variables
        self.var_email = StringVar()
        self.var_pass = StringVar()


        img_top= Image.open(r"images\landscape.png")
        img_top = img_top.resize((1530, 650), Image.LANCZOS)  
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimg_top)
        f_lbl.place(x=0, y=0, width=1530, height=650)

        title=Label(self.root,text="FACE RECOGNITION ATTENDANCE SYSTEM", font=("times new roman",35,"bold"), bg="white", fg="black")
        title.place(x=0,y=0,width=1300,height=50)

        #===========time=============
        def time():
            string = strftime("%H:%M:%S %p")
            lbl.config(text=string)
            lbl.after(1000, time)
        lbl = Label(self.root, font=("times new roman", 14, "bold"), bg="white",fg="Blue")
        lbl.place(x=0, y=0, width=100, height=50)
        time()


        frame=Frame(self.root,bg="black")
        frame.place(x=460,y=150,width=330,height=400)

        img= Image.open(r"images\user.png")
        img = img.resize((80, 80), Image.LANCZOS)  
        self.photoimg = ImageTk.PhotoImage(img)

        f_lbl = Label(image=self.photoimg,bg="black",borderwidth=0)
        f_lbl.place(x=590, y=155, width=80, height=80)

        title=Label(frame,text="Get Started", font=("times new roman",20,"bold"), bg="black", fg="white")
        title.place(x=95,y=90)

        #label
        user_label=Label(frame,text="Username:",font=("times new roman",13,"bold"),bg="black",fg="white")
        user_label.place(x=30,y=145)

        self.user_entry=ttk.Entry(frame,font=("times new roman",13,"bold"))
        self.user_entry.place(x=30,y=175,width=270)

        passwd=Label(frame,text="Password:",font=("times new roman",13,"bold"),bg="black",fg="white")
        passwd.place(x=30,y=215)

        self.passwrd=ttk.Entry(frame,font=("times new roman",13,"bold"))
        self.passwrd.place(x=30,y=240,width=270)

        #login button
        login_btn=Button(frame,text="Login",command=self.login,width=18,font=("times new roman",15,"bold"),bd=3,relief=RIDGE,bg="red",fg="white")
        login_btn.place(x=100,y=290,width=120,height=30)

        #registration button
        registration_btn=Button(frame,text="New User Registration",command=self.reg_window,width=18,font=("times new roman",12,"bold"),borderwidth=0,bg="black",fg="white")
        registration_btn.place(x=20,y=330,width=180,height=30)

        #fgtpass button
        fgtpass_btn=Button(frame,text="Forgot password",command=self.fgtpass,width=18,font=("times new roman",12,"bold"),borderwidth=0,bg="black",fg="white")
        fgtpass_btn.place(x=0,y=355,width=180,height=30)

    def reg_window(self):
        self.new_window=Toplevel(self.root)
        self.app=reg(self.new_window)
    
    def login(self):
        if self.user_entry.get()=="" or self.passwrd.get()=="":
            messagebox.showerror("Error","All fields are required",parent=self.root)
        elif self.user_entry.get()=="admin" and self.passwrd.get()=="admin":
            messagebox.showinfo("Success","Welcome Admin",parent=self.root)
        else:
            conn=mysql.connector.connect(host="localhost",username="root",database="studentdetails")
            my_cursor=conn.cursor()
            my_cursor.execute("select * from register where email=%s and password=%s",(
                self.var_email.get(),
                self.var_pass.get()
                            ))
            row=my_cursor.fetchone()
            if row!=None:
                messagebox.showinfo("Error","Invalid username and password",parent=self.root)
            else:
                open_main=messagebox.askyesno("YesNo","Access only admins")
                if open_main>0:
                    self.new_window=Toplevel(self.root)
                    self.app=face_recog(self.new_window)
                    
                else:
                    if not open_main:
                        return
            conn.commit()
            conn.close()

    #============reset password==========
    def reset_pass(self):
        if self.combo_sec.get()=="Selecct":
            messagebox.showerror("Error","Select the security question",parent=self.root)
        elif self.txt_ans.get()=="":
            messagebox.showerror("Error","Please enter the answer",parent=self.root)
        elif self.txt_newpasswd.get()=="":
            messagebox.showerror("Error","Please enter the new password",parent=self.root)
        else:
            conn=mysql.connector.connect(host="localhost",username="root",database="studentdetails")
            my_cursor=conn.cursor()
            query=("select * from register where email=%s and security ques=%s and security ans=%s")
            value=(self.user_entry.get(),self.combo_sec.get(),self.txt_ans.get())
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            #print(row)
            if row==None:
                messagebox.showerror("Error","Please enter the correct password")
            else:
                query=("update register set password=%s where email=%s")
                value=(self.txt_newpasswd.get(),self.user_entry.get())
                my_cursor.execute(query,value)
                conn.commit()
                conn.close()
                messagebox.showinfo("Success","Your password has been reset,please login with new password")



    
    #=======forget password=============
    def fgtpass(self):
        if self.user_entry.get()=="":
            messagebox.showerror("Error","Please enter the email address to reset password")
        else:
            conn=mysql.connector.connect(host="localhost",username="root",database="studentdetails")
            my_cursor=conn.cursor()
            query=("select * from register where email=%s")
            value=(self.user_entry.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            #print(row)
            if row==None:
                messagebox.showerror("Error","Please enter the valid email address to reset password")
            else:
                conn.close()
                self.root2=Toplevel()
                self.root2.title("Forget password")
                self.root2.geometry("340x450+610+200")

                dep_label=Label(self.root2,text="Forget Password:",font=("times new roman",20,"bold"),bg="white",fg="red")
                dep_label.place(x=0,y=10,relwidth=1)

                #security
                security=Label(self.root2,text="Security Questions:",font=("times new roman",13,"bold"),fg="black",bg="white")
                security.place(x=30,y=80)

                self.combo_sec=ttk.Combobox(self.root2,font=("times new roman",13,"bold"),width=14,state="read only")
                self.combo_sec["values"]=("Select","Your birth place","Your mother's name","Your pet name")
                self.combo_sec.place(x=30,y=110,width=230)
                self.combo_sec.current(0)

                ans=Label(self.root2,text="Security Answer:",font=("times new roman",13,"bold"),fg="black",bg="white")
                ans.place(x=30,y=150)

                self.txt_ans=ttk.Entry(self.root2,font=("times new roman",13,"bold"))
                self.txt_ans.place(x=30,y=180,width=230)

                newpasswd=Label(self.root2,text="Password:",font=("times new roman",13,"bold"),fg="black",bg="white")
                newpasswd.place(x=30,y=220)

                self.txt_newpasswd=ttk.Entry(self.root2,textvariable=self.var_pass,font=("times new roman",13,"bold"))
                self.txt_newpasswd.place(x=30,y=250,width=230)

                res_btn=Button(self.root2,text="Reset",command=self.reset_pass,width=18,font=("times new roman",15,"bold"),bg="blue",fg="white")
                res_btn.place(x=70,y=290)





class reg:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("face recognition system")

        #=====variables=============
        self.var_fname = StringVar()
        self.var_lname = StringVar()
        self.var_contact = StringVar()
        self.var_email = StringVar()
        self.var_securityQ = StringVar()
        self.var_securityA = StringVar()
        self.var_pass = StringVar()
        self.var_confpass = StringVar()


        img_top= Image.open(r"images\nature.webp")
        img_top = img_top.resize((1530, 680), Image.LANCZOS)  
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimg_top)
        f_lbl.place(x=0, y=0, width=1530, height=680)

        frame=Frame(self.root,bg="white")
        frame.place(x=300,y=70,width=700,height=500)

        reg_label=Label(frame,text="REGISTER HERE",font=("times new roman",20,"bold"),fg="green",bg="white")
        reg_label.place(x=5,y=5)

        #name
        fname=Label(frame,text="First Name:",font=("times new roman",13,"bold"),fg="black",bg="white")
        fname.place(x=30,y=80)

        fname_entry=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",13,"bold"))
        fname_entry.place(x=30,y=110,width=230)

        lname=Label(frame,text="Last Name:",font=("times new roman",13,"bold"),fg="black",bg="white")
        lname.place(x=370,y=80)

        self.txt_lname=ttk.Entry(frame,textvariable=self.var_lname,font=("times new roman",13,"bold"))
        self.txt_lname.place(x=370,y=110,width=250)

        #contact
        contact=Label(frame,text="Contact No:",font=("times new roman",13,"bold"),fg="black",bg="white")
        contact.place(x=30,y=150)

        self.txt_contact=ttk.Entry(frame,textvariable=self.var_contact,font=("times new roman",13,"bold"))
        self.txt_contact.place(x=30,y=180,width=230)

        #email
        email=Label(frame,text="EmailId:",font=("times new roman",13,"bold"),fg="black",bg="white")
        email.place(x=370,y=150)

        self.txt_email=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",13,"bold"))
        self.txt_email.place(x=370,y=180,width=250)

        #security
        security=Label(frame,text="Security Questions:",font=("times new roman",13,"bold"),fg="black",bg="white")
        security.place(x=30,y=220)

        self.combo_sec=ttk.Combobox(frame,textvariable=self.var_securityQ,font=("times new roman",13,"bold"),width=14,state="read only")
        self.combo_sec["values"]=("Select","Your birth place","Your mother's name","Your pet name")
        self.combo_sec.place(x=30,y=250,width=230)
        self.combo_sec.current(0)

        ans=Label(frame,text="Security Answer:",font=("times new roman",13,"bold"),fg="black",bg="white")
        ans.place(x=370,y=220)

        self.txt_ans=ttk.Entry(frame,textvariable=self.var_securityA,font=("times new roman",13,"bold"))
        self.txt_ans.place(x=370,y=250,width=250)

        #passwd
        passwd=Label(frame,text="Password:",font=("times new roman",13,"bold"),fg="black",bg="white")
        passwd.place(x=30,y=290)

        self.txt_passwd=ttk.Entry(frame,textvariable=self.var_pass,font=("times new roman",13,"bold"))
        self.txt_passwd.place(x=30,y=320,width=230)

        cnfpasswd=Label(frame,text="Confirm Password:",font=("times new roman",13,"bold"),fg="black",bg="white")
        cnfpasswd.place(x=370,y=290)

        self.txt_cnfpasswd=ttk.Entry(frame,textvariable=self.var_confpass,font=("times new roman",13,"bold"))
        self.txt_cnfpasswd.place(x=370,y=320,width=250)

        self.var_check=IntVar()
        chk_btn=Checkbutton(frame,variable=self.var_check,text="I agree the terms and conditions",font=("times new roman",12,"bold"),onvalue=1,offvalue=0)
        chk_btn.place(x=30,y=360)

        #buttons
        reg_btn=Button(frame,text="Register",command=self.register_data,font=("times new roman",15,"bold"),bg="light green")
        reg_btn.place(x=30,y=410,width=150)

        login_btn=Button(frame,text="Login",font=("times new roman",15,"bold"),bg="light green")
        login_btn.place(x=370,y=410,width=150)

    def register_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_securityQ.get=="Select":
            messagebox.showerror("Error","All fields are required",parent=self.root)
        elif self.var_pass.get()!=self.var_confpass.get():
            messagebox.showerror("Error","Password and Confirm Password should be same",parent=self.root)
        elif self.var_check.get()==0:
            messagebox.showerror("Error","Please agree the terms and conditions",parent=self.root)
        else:
            conn=mysql.connector.connect(host="localhost",username="root",database="studentdetails")
            my_cursor=conn.cursor()
            query=("select * from register where email=%s")
            value=(self.var_email.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()    
            if row!=None:
                messagebox.showerror("Error","User already exist,please try another email",parent=self.root)
            else:
                my_cursor.execute("insert into register values(%s,%s,%s,%s,%s,%s,%s)",(
                    self.var_fname.get(),
                    self.var_lname.get(),
                    self.var_contact.get(),
                    self.var_email.get(),
                    self.var_securityQ.get(),
                    self.var_securityA.get(),
                    self.var_pass.get(),
                    

                ))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success","Registered Successfully",parent=self.root)

class face_recog:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("face recognition system")


        #img1
        img= Image.open(r"images\download.jpeg")
        img = img.resize((450, 130), Image.LANCZOS)  
        self.photoimg = ImageTk.PhotoImage(img)

        f_lbl = Label(self.root, image=self.photoimg)
        f_lbl.place(x=0, y=0, width=450, height=130)


        #img2
        img1= Image.open(r"images\Benefits-of-facial-recognition-attendance-system.png")
        img1 = img1.resize((420, 130), Image.LANCZOS)  
        self.photoimg1 = ImageTk.PhotoImage(img1)

        f_lbl = Label(self.root, image=self.photoimg1)
        f_lbl.place(x=450, y=0, width=420, height=130)

        #img3
        img2= Image.open(r"images\download.jpeg")
        img2 = img2.resize((450, 130), Image.LANCZOS)  
        self.photoimg2 = ImageTk.PhotoImage(img2)

        f_lbl = Label(self.root, image=self.photoimg2)
        f_lbl.place(x=870, y=0, width=450, height=130)


        #bg_image
        img3= Image.open(r"images\360_F_495758885_x8DGYXTVxyVB6uHkTt7El5uRRhplVzGQ.jpg")
        img3 = img3.resize((1920, 1080), Image.LANCZOS)  
        self.photoimg3 = ImageTk.PhotoImage(img3)

        bg_img = Label(self.root, image=self.photoimg3)
        bg_img.place(x=0, y=130, width=1920, height=1080)

        title=Label(bg_img,text="FACE RECOGNITION ATTENDANCE SYSTEM", font=("times new roman",35,"bold"), bg="white", fg="black")
        title.place(x=0,y=0,width=1300,height=50)

        #===========time=============
        def time():
            string = strftime("%H:%M:%S %p")
            lbl.config(text=string)
            lbl.after(1000, time)
        lbl = Label(bg_img, font=("times new roman", 14, "bold"), bg="white",fg="Blue")
        lbl.place(x=0, y=0, width=100, height=50)
        time()

        #student button
        img4= Image.open(r"images\student.png")
        img4 = img4.resize((220,220), Image.LANCZOS)  
        self.photoimg4 = ImageTk.PhotoImage(img4)

        b1=Button(bg_img,image=self.photoimg4,command=self.student_details, cursor="hand2")
        b1.place(x=110,y=70,width=190,height=170)

        b1a=Button(bg_img,text="Student Details",command=self.student_details, cursor="hand2",font=("times new roman",18,"bold"), bg="darkblue", fg="white")
        b1a.place(x=110,y=230,width=190,height=25)

        #detect face button
        img5= Image.open(r"images\face.png")
        img5 = img5.resize((220,220), Image.LANCZOS)  
        self.photoimg5 = ImageTk.PhotoImage(img5)

        b1=Button(bg_img,image=self.photoimg5, cursor="hand2",command=self.face_data)
        b1.place(x=370,y=70,width=190,height=170)

        b1a=Button(bg_img,text="Face Detector", cursor="hand2",command=self.face_data,font=("times new roman",18,"bold"), bg="darkblue", fg="white")
        b1a.place(x=370,y=230,width=190,height=25)

        #attendance button
        img6= Image.open(r"images\attendance.png")
        img6 = img6.resize((220,220), Image.LANCZOS)  
        self.photoimg6 = ImageTk.PhotoImage(img6)

        b1=Button(bg_img,image=self.photoimg6, cursor="hand2",command=self.attendance_data)
        b1.place(x=630,y=70,width=190,height=170)

        b1a=Button(bg_img,text="Attendance", cursor="hand2",command=self.attendance_data,font=("times new roman",18,"bold"), bg="darkblue", fg="white")
        b1a.place(x=630,y=230,width=190,height=25)

        
        #help desk button
        img7= Image.open(r"images\help.png")
        img7 = img7.resize((220,220), Image.LANCZOS)  
        self.photoimg7 = ImageTk.PhotoImage(img7)

        b1=Button(bg_img,image=self.photoimg7, cursor="hand2",command=self.help_data)
        b1.place(x=890,y=70,width=190,height=170)

        b1a=Button(bg_img,text="Help Desk", cursor="hand2",command=self.help_data,font=("times new roman",18,"bold"), bg="darkblue", fg="white")
        b1a.place(x=890,y=230,width=190,height=25)

        #train data button
        img8= Image.open(r"images\Training-Data-Feature-1024x657.jpg")
        img8 = img8.resize((220,220), Image.LANCZOS)  
        self.photoimg8 = ImageTk.PhotoImage(img8)

        b1=Button(bg_img,image=self.photoimg8, cursor="hand2",command=self.train_data)
        b1.place(x=110,y=290,width=190,height=170)

        b1a=Button(bg_img,text="Train Data", cursor="hand2",command=self.train_data,font=("times new roman",18,"bold"), bg="darkblue", fg="white")
        b1a.place(x=110,y=450,width=190,height=25)

        #photos button
        img9= Image.open(r"images\istockphoto-1270625602-612x612.jpg")
        img9 = img9.resize((220,220), Image.LANCZOS)  
        self.photoimg9 = ImageTk.PhotoImage(img9)

        b1=Button(bg_img,image=self.photoimg9, cursor="hand2",command=self.open_img)
        b1.place(x=370,y=290,width=190,height=170)

        b1a=Button(bg_img,text="Photos", cursor="hand2",command=self.open_img,font=("times new roman",18,"bold"), bg="darkblue", fg="white")
        b1a.place(x=370,y=450,width=190,height=25)

        #developer button
        img10= Image.open(r"images\istockphoto-1356364287-612x612.jpg")
        img10 = img10.resize((220,220), Image.LANCZOS)  
        self.photoimg10 = ImageTk.PhotoImage(img10)

        b1=Button(bg_img,image=self.photoimg10, cursor="hand2",command=self.developer_data)
        b1.place(x=630,y=290,width=190,height=170)

        b1a=Button(bg_img,text="Developer", cursor="hand2",command=self.developer_data,font=("times new roman",18,"bold"), bg="darkblue", fg="white")
        b1a.place(x=630,y=450,width=190,height=25)

        #exit button
        img11= Image.open(r"images\sign-575715_1280.webp")
        img11 = img11.resize((220,220), Image.LANCZOS)  
        self.photoimg11 = ImageTk.PhotoImage(img11)

        b1=Button(bg_img,image=self.photoimg11, cursor="hand2",command=self.iExit)
        b1.place(x=890,y=290,width=190,height=170)

        b1a=Button(bg_img,text="Exit", cursor="hand2",command=self.iExit,font=("times new roman",18,"bold"), bg="darkblue", fg="white")
        b1a.place(x=890,y=450,width=190,height=25)



    def open_img(self):
        os.startfile("data")

    def iExit(self):
        self.iExit = tkinter.messagebox.askyesno("Face Recognition System", "Are you sure exit this project",parent=self.root)
        if self.iExit > 0:
            self.root.destroy()
        else:
            return
    
    #==========function buttons=====================
    def student_details(self):
        self.new_window=Toplevel(self.root)
        self.app=student(self.new_window)

    def train_data(self):
        self.new_window=Toplevel(self.root)
        self.app=train(self.new_window)

    def face_data(self):
        self.new_window=Toplevel(self.root)
        self.app=recognition(self.new_window)

    def attendance_data(self):
        self.new_window=Toplevel(self.root)
        self.app=attendance(self.new_window)

    def developer_data(self):
        self.new_window=Toplevel(self.root)
        self.app=developer(self.new_window)

    def help_data(self):
        self.new_window=Toplevel(self.root)
        self.app=help(self.new_window)










if __name__ == "__main__":
    main()