from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import cv2   #open source computer vision libraray


mydb = mysql.connector.connect(host="localhost",user="root")


class reg:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("face recognition system")

        #=====variables=============
        self.var_fname = StringVar()
        self.var_lname = StringVar()
        self.var_contact = StringVar()
        self.var_email = StringVar()
        self.var_securityQ = StringVar()
        self.var_securityA = StringVar()
        self.var_pass = StringVar()
        self.var_confpass = StringVar()


        img_top= Image.open(r"images\nature.webp")
        img_top = img_top.resize((1530, 680), Image.LANCZOS)  
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimg_top)
        f_lbl.place(x=0, y=0, width=1530, height=680)

        frame=Frame(self.root,bg="white")
        frame.place(x=300,y=70,width=700,height=500)

        reg_label=Label(frame,text="REGISTER HERE",font=("times new roman",20,"bold"),fg="green",bg="white")
        reg_label.place(x=5,y=5)

        #name
        fname=Label(frame,text="First Name:",font=("times new roman",13,"bold"),fg="black",bg="white")
        fname.place(x=30,y=80)

        fname_entry=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",13,"bold"))
        fname_entry.place(x=30,y=110,width=230)

        lname=Label(frame,text="Last Name:",font=("times new roman",13,"bold"),fg="black",bg="white")
        lname.place(x=370,y=80)

        self.txt_lname=ttk.Entry(frame,textvariable=self.var_lname,font=("times new roman",13,"bold"))
        self.txt_lname.place(x=370,y=110,width=250)

        #contact
        contact=Label(frame,text="Contact No:",font=("times new roman",13,"bold"),fg="black",bg="white")
        contact.place(x=30,y=150)

        self.txt_contact=ttk.Entry(frame,textvariable=self.var_contact,font=("times new roman",13,"bold"))
        self.txt_contact.place(x=30,y=180,width=230)

        #email
        email=Label(frame,text="EmailId:",font=("times new roman",13,"bold"),fg="black",bg="white")
        email.place(x=370,y=150)

        self.txt_email=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",13,"bold"))
        self.txt_email.place(x=370,y=180,width=250)

        #security
        security=Label(frame,text="Security Questions:",font=("times new roman",13,"bold"),fg="black",bg="white")
        security.place(x=30,y=220)

        self.combo_sec=ttk.Combobox(frame,textvariable=self.var_securityQ,font=("times new roman",13,"bold"),width=14,state="read only")
        self.combo_sec["values"]=("Select","Your birth place","Your mother's name","Your pet name")
        self.combo_sec.place(x=30,y=250,width=230)
        self.combo_sec.current(0)

        ans=Label(frame,text="Security Answer:",font=("times new roman",13,"bold"),fg="black",bg="white")
        ans.place(x=370,y=220)

        self.txt_ans=ttk.Entry(frame,textvariable=self.var_securityA,font=("times new roman",13,"bold"))
        self.txt_ans.place(x=370,y=250,width=250)

        #passwd
        passwd=Label(frame,text="Password:",font=("times new roman",13,"bold"),fg="black",bg="white")
        passwd.place(x=30,y=290)

        self.txt_passwd=ttk.Entry(frame,textvariable=self.var_pass,font=("times new roman",13,"bold"))
        self.txt_passwd.place(x=30,y=320,width=230)

        cnfpasswd=Label(frame,text="Confirm Password:",font=("times new roman",13,"bold"),fg="black",bg="white")
        cnfpasswd.place(x=370,y=290)

        self.txt_cnfpasswd=ttk.Entry(frame,textvariable=self.var_confpass,font=("times new roman",13,"bold"))
        self.txt_cnfpasswd.place(x=370,y=320,width=250)

        self.var_check=IntVar()
        chk_btn=Checkbutton(frame,variable=self.var_check,text="I agree the terms and conditions",font=("times new roman",12,"bold"),onvalue=1,offvalue=0)
        chk_btn.place(x=30,y=360)

        #buttons
        reg_btn=Button(frame,text="Register",command=self.register_data,font=("times new roman",15,"bold"),bg="light green")
        reg_btn.place(x=30,y=410,width=150)

        login_btn=Button(frame,text="Login",font=("times new roman",15,"bold"),bg="light green")
        login_btn.place(x=370,y=410,width=150)

    def register_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_securityQ.get=="Select":
            messagebox.showerror("Error","All fields are required",parent=self.root)
        elif self.var_pass.get()!=self.var_confpass.get():
            messagebox.showerror("Error","Password and Confirm Password should be same",parent=self.root)
        elif self.var_check.get()==0:
            messagebox.showerror("Error","Please agree the terms and conditions",parent=self.root)
        else:
            conn=mysql.connector.connect(host="localhost",username="root",database="studentdetails")
            my_cursor=conn.cursor()
            query=("select * from register where email=%s")
            value=(self.var_email.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()    
            if row!=None:
                messagebox.showerror("Error","User already exist,please try another email",parent=self.root)
            else:
                my_cursor.execute("insert into register values(%s,%s,%s,%s,%s,%s,%s)",(
                    self.var_fname.get(),
                    self.var_lname.get(),
                    self.var_contact.get(),
                    self.var_email.get(),
                    self.var_securityQ.get(),
                    self.var_securityA.get(),
                    self.var_pass.get(),
                    

                ))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success","Registered Successfully",parent=self.root)




if __name__ == "__main__":
    root = Tk()
    obj = reg(root)
    root.mainloop()
